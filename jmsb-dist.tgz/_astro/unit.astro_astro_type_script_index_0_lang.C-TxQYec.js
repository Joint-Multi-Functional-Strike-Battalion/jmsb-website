import{a as e,i as t,o as n}from"./pac.DF4867-w.js";n(`orbat`).then(n=>{let r=document.getElementById(`ob`);r.innerHTML=n.elements.map(n=>{let r=n.squads[0]?.type||`inf`,i=(n.callsign||n.name||``).toLowerCase(),a=i===`ghost`?`/ghost-alpha.png`:`/insignia/${i}.svg`;return`<div class="el${r===`hq`?` hq`:``}">
					<img class="emblem" src="${t(a)}" alt="" onerror="this.remove()">
					<div class="cs">${t(e(n.callsign||n.name))}</div>
					<div class="nm">${t(e(n.name))}</div>
					${n.squads.map(n=>`<div class="sq"><div class="sqn"><span class="sym ${t(n.type)}"></span>${t(e(n.name))}</div></div>`).join(``)}
				</div>`}).join(``)}).catch(()=>{}),n(`roster`).then(e=>{let n=document.getElementById(`ladder`),r=Object.entries(e.ranks||{}).sort((e,t)=>e[1].order-t[1].order);n&&r.length&&(n.innerHTML=r.map(([,e])=>`<li>
				<span class="ins">${e.insignia?`<img src="${t(e.insignia)}" alt="">`:``}</span>
				<b>${t(e.name)}</b>
				<span class="pg">${t(e.payGrade||``)}</span>
			</li>`).join(``))}).catch(()=>{});