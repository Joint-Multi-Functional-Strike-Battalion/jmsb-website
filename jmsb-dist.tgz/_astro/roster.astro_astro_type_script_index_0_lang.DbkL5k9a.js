import{a as e,i as t,l as n,o as r,s as i,t as a}from"./pac.DF4867-w.js";var o=document.getElementById(`roster`),s=document.getElementById(`rs-q`),c=document.getElementById(`rs-sort`),l=document.getElementById(`rs-count`),u=e=>{let t=new Date(e+`T00:00:00`);return Number.isNaN(t.getTime())?``:new Intl.DateTimeFormat(void 0,{month:`long`,year:`numeric`}).format(t)},d=e=>{let t=2166136261;for(let n of e)t^=n.charCodeAt(0),t=Math.imul(t,16777619)>>>0;let n=0,r=``;for(;n<220;){let e=1+(t&3);t=Math.imul(t,1103515245)+12345>>>0,r+=`<rect x="${n}" y="0" width="${e}" height="28"/>`,n+=e+1+(t&3),t=Math.imul(t,1103515245)+12345>>>0}return`<svg class="idc-bar" viewBox="0 0 224 28" aria-hidden="true">${r}</svg>`},f=(t,r)=>{let a=t.ranks[r.rank],o=r.skills.map(e=>i(t.skills[e],e)),s=r.awards.map(e=>t.awards[e]||{name:e,image:null}),c=r.role&&t.roles[r.role]?n(t.roles[r.role])+(r.group?`, ${e(r.group)}`:``):r.group?e(r.group):`Alpha Company`,l=r.status?t.statuses[r.status]||r.status:``;return{p:r,quals:o,awards:s,assignment:c,status:l,rankName:a?a.name:`Private`,rankOrder:a?a.order:-1,payGrade:a&&a.payGrade?a.payGrade:``,insignia:a&&a.insignia?a.insignia:``,enlisted:u(r.enlisted),haystack:[r.name,a?a.name:``,a&&a.payGrade||``,c,l,...o,...s.map(e=>e.name)].join(` `).toLowerCase()}},p=e=>{let n=e.p.avatar?`<img class="idc-photo" src="${t(e.p.avatar)}" alt="">`:`<div class="idc-photo idc-nophoto"><img src="/logo-patch.svg" alt=""></div>`;return`<article class="idc">
				<div class="idc-top"><span>1st JMSB · Alpha Company · Identification</span>${e.p.staff?`<span class="idc-stamp">Staff</span>`:``}<img src="/logo-patch.svg" alt="" width="36" height="36"></div>
				<div class="idc-body">
					<div class="idc-left">
						${n}
						<div class="idc-rank">${e.insignia?`<img src="${t(e.insignia)}" alt="">`:``}<b>${t(e.rankName)}</b></div>
					</div>
					<dl class="idc-fields">
						<dt>Name</dt><dd class="idc-name">${t(e.p.name)}</dd>
						<dt>Pay grade</dt><dd>${t(e.payGrade)}</dd>
						<dt>Assignment</dt><dd>${t(e.assignment)}</dd>
						<dt>Enlisted</dt><dd>${t(e.enlisted)}</dd>
					</dl>
					<div class="idc-quals">
						<span class="idc-label">Qualified as</span>
						${e.quals.length?`<ul>${e.quals.map(e=>`<li>${t(e)}</li>`).join(``)}</ul>`:`<p class="muted">None yet</p>`}
					</div>
					<div class="idc-awards">
						<span class="idc-label">Awards</span>
						${e.awards.length?`<ul>${e.awards.map(e=>`<li>${e.image?`<img src="${t(e.image)}" alt="" title="${t(e.name)}">`:``}<span>${t(e.name)}</span></li>`).join(``)}</ul>`:`<p class="muted">None yet</p>`}
					</div>
				</div>
				<div class="idc-foot">${d(e.p.name)}<span class="idc-status${e.status&&e.status.toLowerCase()!==`active`?` off`:``}">${e.status?t(e.status.toUpperCase()):`ON THE BOOKS`}</span></div>
			</article>`},m={rank:(e,t)=>t.rankOrder-e.rankOrder||e.p.name.localeCompare(t.p.name),name:(e,t)=>e.p.name.localeCompare(t.p.name),oldest:(e,t)=>(e.p.enlisted||`9999`).localeCompare(t.p.enlisted||`9999`)||e.p.name.localeCompare(t.p.name),newest:(e,t)=>(t.p.enlisted||``).localeCompare(e.p.enlisted||``)||e.p.name.localeCompare(t.p.name)},h=[],g=()=>{let e=s.value.trim().toLowerCase(),n=h.filter(t=>!e||e.split(/\s+/).every(e=>t.haystack.includes(e)));n.sort(m[c.value]||m.rank),l.textContent=e?`${n.length} of ${h.length}`:`${h.length} on the books`;let r=n.filter(e=>e.p.staff),i=n.filter(e=>!e.p.staff),a=``;r.length&&(a+=`<div class="rs-group"><h2>Staff</h2><div class="idc-grid">${r.map(p).join(``)}</div></div>`),i.length&&(a+=`<div class="rs-group"><div class="idc-grid">${i.map(p).join(``)}</div></div>`),n.length||(a=e?`<p class="dim">Nobody matches "${t(s.value.trim())}".</p>`:`<p class="dim">The rest of the company goes here as people enlist.</p>`),o.innerHTML=a};s.addEventListener(`input`,g),c.addEventListener(`change`,g),r(`roster`).then(e=>{e.players.length?(h=e.players.map(t=>f(e,t)),g()):o.innerHTML=`<p class="dim">The roster is being set up.</p>`}).catch(()=>{o.innerHTML=`<p class="dim">The roster could not be read right now. It is on <a href="${t(a)}/" target="_blank" rel="noopener">TAC//PAC</a>.</p>`});