import{c as e,i as t,n,o as r,r as i,t as a}from"./pac.DF4867-w.js";var o=document.getElementById(`ev`),s=(n,r)=>`<li class="ev${r?` past`:``}${n.cancelled?` cancelled`:``}">
			<span class="d">${t(e(n.start))}</span>
			<div><div class="t">${t(n.title)}${n.cancelled?` <span class="pill hot">cancelled</span>`:``}</div>${n.summary?`<p class="s">${t(n.summary)}</p>`:``}</div>
			<span class="srv">${t(n.server||``)}${n.minutes?` · ${n.minutes%60==0?n.minutes/60+` h`:n.minutes+` min`}`:``}</span>
		</li>`;r(`events`).then(r=>{let a=``;if(r.next){let n=r.next;a+=`<div class="evnext poster" id="evnext">
					<canvas class="topo" aria-hidden="true"></canvas>
					<div class="p-class">NEXT OPERATION // ${t(e(n.start).toUpperCase())}</div>
					<div class="p-body"><p class="eyebrow">Next up</p><h2>${t(n.title)}</h2>
						<p class="when">${t(e(n.start,!0))}${n.server?` · ${t(n.server)} server`:``}${n.minutes?` · ${n.minutes%60==0?n.minutes/60+` h`:n.minutes+` min`}`:``}</p>
						${n.summary?`<p class="sum">${t(n.summary)}</p>`:``}</div>
					<div class="count" aria-label="Time until it starts"><span><b data-d>0</b><i>days</i></span><span><b data-h>00</b><i>hrs</i></span><span><b data-m>00</b><i>min</i></span><span><b data-s>00</b><i>sec</i></span></div>
					<div class="p-class p-foot">${t((n.server||`JMSB`).toUpperCase())} SERVER // JMSB.INFO</div>
				</div>`}a+=`<h2 style="margin-bottom:14px">Coming up</h2>`,a+=r.upcoming.length?`<ul class="evlist">${r.upcoming.map(e=>s(e,!1)).join(``)}</ul>`:`<p class="dim" style="margin-bottom:32px">Nothing on the calendar yet. Operation nights are announced on Discord.</p>`,r.recent.length&&(a+=`<h2 style="margin-bottom:14px">Played</h2><ul class="evlist">${r.recent.map(e=>s(e,!0)).join(``)}</ul>`),o.innerHTML=a;let c=document.getElementById(`evnext`);c&&(n(c.querySelector(`.topo`),c,37),i(c,r.next.start,()=>{c.querySelector(`.count`).innerHTML=`<b>Under way</b>`}))}).catch(()=>{o.innerHTML=`<p class="dim">The calendar could not be read right now. It is on <a href="${t(a)}/?page=events" target="_blank" rel="noopener">TAC//PAC</a>.</p>`});